// 阅读页面功能实现
class NovelReader {
    constructor() {
        this.novelId = this.getNovelIdFromUrl();
        this.settings = this.loadSettings();
        this.readingProgress = this.loadProgress();
        
        // 初始化离线管理器（如果存在）
        this.offlineManager = null;
        this.isOffline = false;
        this.initOfflineManager();

        this.initializeElements();
        this.bindEvents();
        this.applySettings();
        this.loadNovel();
    }

    // 从URL参数获取小说ID
    getNovelIdFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const id = urlParams.get('id');
        if (!id) {
            // 如果没有ID，显示错误并提供返回选项
            this.showError('未找到小说ID参数');
            return null;
        }
        return id;
    }

    // 加载用户设置
    loadSettings() {
        const defaultSettings = {
            fontSize: 16,
            theme: 'light',
            // 智能排版设置
            lineHeight: 'auto', // auto, 1.5, 1.8, 2.0, 2.2
            letterSpacing: 'auto', // auto, normal, 0.5px, 1px, 1.5px
            paragraphSpacing: 'auto', // auto, normal, large, extra-large
            textAlign: 'justify', // left, justify
            // 字体设置
            fontFamily: 'system', // system, serif, sans-serif, source-han-serif, source-han-sans, noto-serif, noto-sans, fang-song, kai-ti
            fontWeight: '400', // 300, 400, 500, 600, 700
            // 页面设置
            pageWidth: 'auto', // auto, narrow, medium, wide
            marginSize: 'auto', // auto, small, medium, large
            // 自定义主题设置
            customTheme: {
                backgroundColor: '#FAF5F0',
                textColor: '#333333',
                contentBackgroundColor: '#FFFFFF'
            }
        };

        const saved = localStorage.getItem('readerSettings');
        return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
    }

    // 加载阅读进度
    loadProgress() {
        const saved = localStorage.getItem(`novel-${this.novelId}-progress`);
        return saved ? JSON.parse(saved) : { position: 0, percentage: 0 };
    }

    // 初始化DOM元素
    initializeElements() {
        this.elements = {
            settingsBtn: document.getElementById('settingsBtn'),
            settingsPanel: document.getElementById('settingsPanel'),
            settingsOverlay: document.getElementById('settingsOverlay'),
            closeSettings: document.getElementById('closeSettings'),
            fontSizeUp: document.getElementById('fontSizeUp'),
            fontSizeDown: document.getElementById('fontSizeDown'),
            fontSizeLabel: document.getElementById('fontSizeLabel'),
            themeButtons: document.querySelectorAll('.theme-btn'),
            // 智能排版控件
            lineHeightSelect: document.getElementById('lineHeightSelect'),
            letterSpacingSelect: document.getElementById('letterSpacingSelect'),
            fontFamilySelect: document.getElementById('fontFamilySelect'),
            fontWeightSelect: document.getElementById('fontWeightSelect'),
            fontSizeSlider: document.getElementById('fontSizeSlider'),
            fontSizeValue: document.getElementById('fontSizeValue'),
            fontPreview: document.getElementById('fontPreview'),
            alignButtons: document.querySelectorAll('.align-btn'),
            // 自定义主题控件
            customThemeBtn: document.getElementById('customThemeBtn'),
            customThemePanel: document.getElementById('customThemePanel'),
            closeCustomTheme: document.getElementById('closeCustomTheme'),
            bgColorPicker: document.getElementById('bgColorPicker'),
            bgColorInput: document.getElementById('bgColorInput'),
            textColorPicker: document.getElementById('textColorPicker'),
            textColorInput: document.getElementById('textColorInput'),
            contentBgColorPicker: document.getElementById('contentBgColorPicker'),
            contentBgColorInput: document.getElementById('contentBgColorInput'),
            presetColorBtns: document.querySelectorAll('.preset-color-btn'),
            applyCustomTheme: document.getElementById('applyCustomTheme'),
            resetCustomTheme: document.getElementById('resetCustomTheme'),
            // 内容元素
            novelTitle: document.getElementById('novelTitle'),
            novelTitleMain: document.getElementById('novelTitleMain'),
            novelViews: document.getElementById('novelViews'),
            publishTime: document.getElementById('publishTime'),
            novelTags: document.getElementById('novelTags'),
            novelSummary: document.getElementById('novelSummary'),
            novelInfo: document.getElementById('novelInfo'),
            novelContent: document.getElementById('novelContent'),
            progressBar: document.getElementById('progressBar'),
            // TTS控件
            voiceSelect: document.getElementById('voiceSelect'),
            speechRateSlider: document.getElementById('speechRateSlider'),
            speechRateValue: document.getElementById('speechRateValue'),
            speechPitchSlider: document.getElementById('speechPitchSlider'),
            speechPitchValue: document.getElementById('speechPitchValue'),
            speechVolumeSlider: document.getElementById('speechVolumeSlider'),
            speechVolumeValue: document.getElementById('speechVolumeValue'),
            ttsTestBtn: document.getElementById('ttsTestBtn'),
            ttsResetBtn: document.getElementById('ttsResetBtn'),
            analyticsBtn: document.getElementById('analyticsBtn'),
            ttsBtn: document.getElementById('ttsBtn'),
            searchBtn: document.getElementById('searchBtn'),
            notesBtn: document.getElementById('notesBtn')

        };
        

    }

    // 绑定事件
    bindEvents() {
        // 设置面板控制
        this.elements.settingsBtn.addEventListener('click', () => this.openSettings());
        this.elements.closeSettings.addEventListener('click', () => this.closeSettings());
        this.elements.settingsOverlay.addEventListener('click', () => this.closeSettings());

        // 字体大小控制
        this.elements.fontSizeUp.addEventListener('click', () => this.changeFontSize(2));
        this.elements.fontSizeDown.addEventListener('click', () => this.changeFontSize(-2));

        // 主题切换
        this.elements.themeButtons.forEach(btn => {
            btn.addEventListener('click', () => this.changeTheme(btn.dataset.theme));
        });

        // 智能排版设置事件
        this.elements.lineHeightSelect.addEventListener('change', (e) => {
            this.settings.lineHeight = e.target.value;
            this.applySmartTypography();
            this.saveSettings();
            this.showToast('行距已更新');
        });

        this.elements.letterSpacingSelect.addEventListener('change', (e) => {
            this.settings.letterSpacing = e.target.value;
            this.applySmartTypography();
            this.saveSettings();
            this.showToast('字距已更新');
        });

        this.elements.fontFamilySelect.addEventListener('change', (e) => {
            this.settings.fontFamily = e.target.value;
            this.updateFontPreview();
            this.applySmartTypography();
            this.saveSettings();
            this.showToast('字体已更新');
        });

        this.elements.fontWeightSelect.addEventListener('change', (e) => {
            this.settings.fontWeight = e.target.value;
            this.updateFontPreview();
            this.applySmartTypography();
            this.saveSettings();
            this.showToast('字体粗细已更新');
        });

        this.elements.fontSizeSlider.addEventListener('input', (e) => {
            const newSize = parseFloat(e.target.value);
            this.settings.fontSize = newSize;
            this.elements.fontSizeValue.textContent = `${newSize}px`;
            this.elements.fontSizeLabel.textContent = `${newSize}px`;
            this.elements.novelContent.style.fontSize = `${newSize}px`;
            this.updateFontPreview();
            this.applySmartTypography();
            this.saveSettings();
        });

        this.elements.alignButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.elements.alignButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.settings.textAlign = btn.dataset.align;
                this.applySmartTypography();
                this.saveSettings();
                this.showToast(`已切换到${btn.textContent}`);
            });
        });

        // 自定义主题面板事件
        this.elements.customThemeBtn.addEventListener('click', () => this.openCustomThemePanel());
        this.elements.closeCustomTheme.addEventListener('click', () => this.closeCustomThemePanel());

        // 颜色选择器同步
        this.elements.bgColorPicker.addEventListener('input', (e) => {
            this.elements.bgColorInput.value = e.target.value;
        });
        this.elements.bgColorInput.addEventListener('input', (e) => {
            this.elements.bgColorPicker.value = e.target.value;
        });

        this.elements.textColorPicker.addEventListener('input', (e) => {
            this.elements.textColorInput.value = e.target.value;
        });
        this.elements.textColorInput.addEventListener('input', (e) => {
            this.elements.textColorPicker.value = e.target.value;
        });

        this.elements.contentBgColorPicker.addEventListener('input', (e) => {
            this.elements.contentBgColorInput.value = e.target.value;
        });
        this.elements.contentBgColorInput.addEventListener('input', (e) => {
            this.elements.contentBgColorPicker.value = e.target.value;
        });

        // 预设颜色方案
        this.elements.presetColorBtns.forEach(btn => {
            btn.addEventListener('click', () => this.applyPresetColors(btn.dataset.preset));
        });

        // 应用和重置按钮
        this.elements.applyCustomTheme.addEventListener('click', () => this.applyCustomThemeColors());
        this.elements.resetCustomTheme.addEventListener('click', () => this.resetCustomThemeColors());

        // 滚动事件 - 用于进度保存和进度条更新
        let saveTimer;
        window.addEventListener('scroll', () => {
            this.updateProgressBar();
            
            // 防抖保存进度
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => this.saveProgress(), 1000);
        });

        // 键盘快捷键
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });

        // 页面可见性变化时保存进度
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.saveProgress();
            }
        });

        // 页面卸载前保存进度
        window.addEventListener('beforeunload', () => {
            this.saveProgress();
        });

        // 窗口大小变化时重新应用智能排版
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                this.applySmartTypography();
            }, 300); // 防抖处理
        });


    }

    // 处理键盘快捷键
    handleKeyboardShortcuts(event) {
        // 如果在输入框中，不处理快捷键
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            return;
        }

        switch(event.key) {
            case 'Escape':
                this.closeSettings();
                break;
            case 's':
            case 'S':
                event.preventDefault();
                this.openSettings();
                break;
            case '=':
            case '+':
                event.preventDefault();
                this.changeFontSize(2);
                break;
            case '-':
                event.preventDefault();
                this.changeFontSize(-2);
                break;
            case '1':
                event.preventDefault();
                this.changeTheme('light');
                break;
            case '2':
                event.preventDefault();
                this.changeTheme('sepia');
                break;
            case '3':
                event.preventDefault();
                this.changeTheme('dark');
                break;
        }
    }

    // 应用用户设置
    applySettings() {
        // 应用字体大小
        this.elements.novelContent.style.fontSize = `${this.settings.fontSize}px`;
        this.elements.fontSizeLabel.textContent = `${this.settings.fontSize}px`;

        // 应用主题
        document.body.className = `theme-${this.settings.theme}`;
        this.elements.themeButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === this.settings.theme);
        });

        // 初始化设置控件状态
        this.initializeSettingsControls();

        // 应用智能排版设置
        this.applySmartTypography();

        // 应用设置面板主题
        this.updateSettingsPanelTheme();
    }

    // 初始化设置控件状态
    initializeSettingsControls() {
        // 设置行距选择器
        this.elements.lineHeightSelect.value = this.settings.lineHeight;

        // 设置字距选择器
        this.elements.letterSpacingSelect.value = this.settings.letterSpacing;

        // 设置字体选择器
        this.elements.fontFamilySelect.value = this.settings.fontFamily;

        // 设置字体粗细选择器
        this.elements.fontWeightSelect.value = this.settings.fontWeight;

        // 设置字体大小滑块
        this.elements.fontSizeSlider.value = this.settings.fontSize;
        this.elements.fontSizeValue.textContent = `${this.settings.fontSize}px`;

        // 设置对齐按钮状态
        this.elements.alignButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.align === this.settings.textAlign);
        });

        // 如果当前是自定义主题，应用自定义样式
        if (this.settings.theme === 'custom') {
            this.applyCustomThemeStyles();
        }

        // 更新字体预览
        this.updateFontPreview();
    }

    // 更新字体预览
    updateFontPreview() {
        if (!this.elements.fontPreview) return;

        // 应用当前字体设置到预览区域
        const fontFamily = this.getFontFamilyCSS(this.settings.fontFamily);
        this.elements.fontPreview.style.fontFamily = fontFamily;
        this.elements.fontPreview.style.fontWeight = this.settings.fontWeight;
        this.elements.fontPreview.style.fontSize = `${this.settings.fontSize}px`;

        // 应用当前主题的颜色
        if (this.settings.theme === 'custom') {
            this.elements.fontPreview.style.color = this.settings.customTheme.textColor;
            this.elements.fontPreview.style.backgroundColor = this.settings.customTheme.contentBackgroundColor;
        } else {
            // 重置为默认样式，让CSS主题生效
            this.elements.fontPreview.style.color = '';
            this.elements.fontPreview.style.backgroundColor = '';
        }
    }

    // 获取字体CSS字符串
    getFontFamilyCSS(fontFamily) {
        switch (fontFamily) {
            case 'serif':
                return '"SimSun", "宋体", "Times New Roman", serif';
            case 'sans-serif':
                return '"Microsoft YaHei", "微软雅黑", "PingFang SC", "Helvetica Neue", sans-serif';
            case 'source-han-serif':
                return '"Source Han Serif SC", "思源宋体", "Noto Serif CJK SC", "SimSun", serif';
            case 'source-han-sans':
                return '"Source Han Sans SC", "思源黑体", "Noto Sans CJK SC", "Microsoft YaHei", sans-serif';
            case 'noto-serif':
                return '"Noto Serif SC", "Source Han Serif SC", "SimSun", serif';
            case 'noto-sans':
                return '"Noto Sans SC", "Source Han Sans SC", "Microsoft YaHei", sans-serif';
            case 'fang-song':
                return '"FangSong", "仿宋", "STFangsong", "华文仿宋", serif';
            case 'kai-ti':
                return '"KaiTi", "楷体", "STKaiti", "华文楷体", serif';
            default:
                return '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif';
        }
    }

    // 更新设置面板主题
    updateSettingsPanelTheme() {
        const panel = this.elements.settingsPanel;
        const theme = this.settings.theme;

        if (theme === 'dark') {
            panel.style.background = '#2A2A2A';
            panel.style.color = '#E0E0E0';
        } else if (theme === 'sepia') {
            panel.style.background = '#FFF9F0';
            panel.style.color = '#5C4033';
        } else {
            panel.style.background = 'white';
            panel.style.color = '#333333';
        }
    }

    // 智能排版系统核心方法
    applySmartTypography() {
        const content = this.elements.novelContent;
        if (!content) return;

        // 获取屏幕信息
        const screenInfo = this.getScreenInfo();

        // 计算最优排版参数
        const typographyParams = this.calculateOptimalTypography(screenInfo);

        // 应用排版样式
        this.applyTypographyStyles(content, typographyParams);

        // 保存计算结果到设置中
        this.updateTypographySettings(typographyParams);
    }

    // 获取屏幕信息
    getScreenInfo() {
        return {
            width: window.innerWidth,
            height: window.innerHeight,
            devicePixelRatio: window.devicePixelRatio || 1,
            isMobile: window.innerWidth <= 768,
            isTablet: window.innerWidth > 768 && window.innerWidth <= 1024,
            isDesktop: window.innerWidth > 1024,
            orientation: window.innerWidth > window.innerHeight ? 'landscape' : 'portrait'
        };
    }

    // 计算最优排版参数
    calculateOptimalTypography(screenInfo) {
        const fontSize = this.settings.fontSize;
        const baseParams = {
            fontSize: fontSize,
            lineHeight: 1.8,
            letterSpacing: 0,
            paragraphSpacing: 1.5,
            maxWidth: 800,
            padding: 32
        };

        // 根据字体大小调整行距
        if (fontSize <= 14) {
            baseParams.lineHeight = 1.9;
        } else if (fontSize >= 20) {
            baseParams.lineHeight = 1.7;
        }

        // 根据屏幕尺寸调整参数
        if (screenInfo.isMobile) {
            baseParams.maxWidth = Math.min(screenInfo.width - 32, 600);
            baseParams.padding = 20;
            baseParams.lineHeight += 0.1; // 移动端增加行距

            if (screenInfo.orientation === 'portrait') {
                baseParams.letterSpacing = 0.3; // 竖屏时增加字距
            }
        } else if (screenInfo.isTablet) {
            baseParams.maxWidth = Math.min(screenInfo.width - 64, 700);
            baseParams.padding = 28;
        } else {
            // 桌面端根据屏幕宽度调整
            if (screenInfo.width > 1400) {
                baseParams.maxWidth = 900;
                baseParams.padding = 40;
            }
        }

        // 根据用户设置覆盖自动计算的值
        if (this.settings.lineHeight !== 'auto') {
            baseParams.lineHeight = parseFloat(this.settings.lineHeight);
        }

        if (this.settings.letterSpacing !== 'auto') {
            if (this.settings.letterSpacing === 'normal') {
                baseParams.letterSpacing = 0;
            } else {
                baseParams.letterSpacing = parseFloat(this.settings.letterSpacing);
            }
        }

        return baseParams;
    }

    // 应用排版样式
    applyTypographyStyles(content, params) {
        // 设置容器样式
        const container = content.closest('.reader-container');
        if (container) {
            container.style.maxWidth = `${params.maxWidth}px`;
        }

        // 设置内容区域样式
        content.style.lineHeight = params.lineHeight;
        content.style.letterSpacing = `${params.letterSpacing}px`;
        content.style.padding = `${params.padding}px`;

        // 设置段落样式
        const paragraphs = content.querySelectorAll('p');
        paragraphs.forEach(p => {
            p.style.marginBottom = `${params.paragraphSpacing}em`;

            // 根据设置应用文本对齐
            if (this.settings.textAlign === 'justify') {
                p.style.textAlign = 'justify';
                p.style.textJustify = 'inter-ideograph'; // 中文优化
            } else {
                p.style.textAlign = this.settings.textAlign;
            }
        });

        // 设置标题样式
        const headings = content.querySelectorAll('h1, h2, h3, h4, h5, h6');
        headings.forEach(heading => {
            heading.style.lineHeight = Math.max(1.3, params.lineHeight - 0.3);
            heading.style.letterSpacing = `${Math.max(0, params.letterSpacing - 0.2)}px`;
        });

        // 应用字体设置
        this.applyFontSettings(content);
    }

    // 应用字体设置
    applyFontSettings(content) {
        const fontFamily = this.getFontFamilyCSS(this.settings.fontFamily);

        content.style.fontFamily = fontFamily;
        content.style.fontWeight = this.settings.fontWeight;

        // 为特定字体添加字体加载检测
        this.ensureFontLoaded(this.settings.fontFamily);
    }

    // 确保字体加载
    ensureFontLoaded(fontFamily) {
        const fontMap = {
            'source-han-serif': 'Source Han Serif SC',
            'source-han-sans': 'Source Han Sans SC',
            'noto-serif': 'Noto Serif SC',
            'noto-sans': 'Noto Sans SC'
        };

        const fontName = fontMap[fontFamily];
        if (fontName && 'fonts' in document) {
            document.fonts.load(`16px "${fontName}"`).then(() => {
                console.log(`字体 ${fontName} 加载完成`);
            }).catch((error) => {
                console.warn(`字体 ${fontName} 加载失败:`, error);
                this.showToast(`字体加载失败，使用备用字体`, 'warning');
            });
        }
    }

    // 更新排版设置
    updateTypographySettings(params) {
        // 如果是自动模式，更新计算出的值
        if (this.settings.lineHeight === 'auto') {
            this.calculatedLineHeight = params.lineHeight;
        }
        if (this.settings.letterSpacing === 'auto') {
            this.calculatedLetterSpacing = params.letterSpacing;
        }
    }

    // 加载小说内容
    async loadNovel() {
        try {
            // 如果有离线管理器，检查是否有离线版本
            if (this.offlineManager) {
                const offlineNovel = await this.offlineManager.getNovel(this.novelId);
                
                if (offlineNovel) {
                    console.log('找到离线缓存版本，使用离线数据');
                    this.isOffline = true;
                    this.displayNovel(offlineNovel);
                    this.updateOfflineIndicator(true);
                    return;
                }
                
                // 没有离线版本，检查网络
                if (!navigator.onLine) {
                    console.log('网络已断开，无法加载小说');
                    this.showError('网络已断开，无法加载小说内容。请先将小说保存到离线库再阅读。');
                    this.updateOfflineStatus && this.updateOfflineStatus(false, true);
                    return;
                }
            }
            
            // 尝试从API加载
            const response = await fetch('/api/novels/' + this.novelId);
            if (response.ok) {
                const data = await response.json();
                
                if (data.success && data.data) {
                    this.isOffline = false;
                    this.displayNovel(data.data);
                    this.updateOfflineIndicator(false);
                    return;
                }
            }

            // 如果没有找到，显示示例内容
            this.displaySampleNovel();
            this.updateOfflineStatus && this.updateOfflineStatus(false);

        } catch (error) {
            console.error('加载小说失败:', error);
            
            // 网络错误时，尝试切换到离线模式
            if (this.offlineManager && !navigator.onLine) {
                const offlineNovel = await this.offlineManager.getNovel(this.novelId);
                if (offlineNovel) {
                    this.isOffline = true;
                    this.displayNovel(offlineNovel);
                    this.updateOfflineIndicator(true);
                    return;
                }
            }
            
            this.displaySampleNovel();
            this.updateOfflineStatus && this.updateOfflineStatus(false);
        }
    }

    // 显示小说内容
    displayNovel(novel) {
        // 更新页面标题
        document.title = `${novel.title} - 小红书风格小说网站`;
        
        // 更新标题
        this.elements.novelTitle.textContent = novel.title;
        this.elements.novelTitleMain.textContent = novel.title;
        
        // 更新小说信息
        this.elements.novelViews.textContent = this.formatViews(novel.views || 0);
        this.elements.publishTime.textContent = this.formatPublishTime(novel.publishTime);
        this.elements.novelSummary.textContent = novel.summary || '暂无简介';
        
        // 更新标签
        if (novel.tags && novel.tags.length > 0) {
            this.elements.novelTags.innerHTML = novel.tags.map(tag => 
                `<span class="tag">${tag}</span>`
            ).join('');
        }
        
        // 显示小说信息卡片
        this.elements.novelInfo.style.display = 'block';
        
        // 格式化并显示内容
        const content = novel.content || this.generateSampleContent(novel.title);
        this.elements.novelContent.innerHTML = this.formatContent(content);

        // 恢复阅读位置
        setTimeout(() => this.restoreProgress(), 100);
        
        // 增加阅读量（模拟）
        this.incrementViews(novel.id);
        
        // 初始化评论系统
        console.log('准备初始化评论系统，小说ID:', novel.id);
        setTimeout(() => {
            if (typeof initCommentsSystem === 'function') {
                console.log('调用initCommentsSystem函数');
                initCommentsSystem(novel.id);
            } else {
                console.error('initCommentsSystem函数未定义');
            }
        }, 500); // 延迟一下确保DOM完全加载
    }

    // 显示示例小说
    displaySampleNovel() {
        const sampleTitle = `示例小说 ${this.novelId}`;
        const sampleContent = this.generateSampleContent(sampleTitle);
        
        // 更新页面标题
        document.title = `${sampleTitle} - 小红书风格小说网站`;
        
        this.elements.novelTitle.textContent = sampleTitle;
        this.elements.novelTitleMain.textContent = sampleTitle;
        
        // 设置示例信息
        this.elements.novelViews.textContent = Math.floor(Math.random() * 5000 + 1000).toString();
        this.elements.publishTime.textContent = '3天前';
        this.elements.novelSummary.textContent = '这是一个示例小说，展示阅读器的各种功能。';
        this.elements.novelTags.innerHTML = '<span class="tag">#示例</span><span class="tag">#测试</span>';
        
        // 显示小说信息卡片
        this.elements.novelInfo.style.display = 'block';
        
        this.elements.novelContent.innerHTML = this.formatContent(sampleContent);

        setTimeout(() => this.restoreProgress(), 100);
        
        // 初始化评论系统
        console.log('准备初始化评论系统（示例），小说ID:', this.novelId);
        setTimeout(() => {
            if (typeof initCommentsSystem === 'function') {
                console.log('调用initCommentsSystem函数（示例）');
                initCommentsSystem(this.novelId);
            } else {
                console.error('initCommentsSystem函数未定义（示例）');
            }
        }, 500); // 延迟一下确保DOM完全加载
    }

    // 生成示例内容
    generateSampleContent(title) {
        return `这是《${title}》的开头。

        夜色如墨，城市的霓虹灯闪烁着迷离的光影。她站在24楼的落地窗前，俯视着这座从不睡眠的都市。

        手机突然响起，屏幕上显示着一个陌生的号码。她犹豫了一下，最终还是接了起来。

        "喂？"

        "终于接电话了。"电话那头传来一个低沉磁性的声音，带着淡淡的笑意。

        她的心跳突然加速，这个声音...她永远不会忘记。

        "是你？"她的声音有些颤抖。

        "是我。我回来了。"

        三年了，整整三年。她以为自己已经忘记了，忘记了那个让她心动的人，忘记了那段刻骨铭心的感情。

        可是现在，仅仅是听到他的声音，所有的记忆都如潮水般涌回。

        "为什么现在才联系我？"她努力让自己的声音听起来平静。

        "因为我想你了。"他的声音很轻，轻得像羽毛，却重重地击在她的心上。

        她闭上眼睛，泪水不争气地滑落。

        "我们见个面好吗？就像以前一样，在那家咖啡店。"

        那家咖啡店，他们第一次相遇的地方，也是最后一次告别的地方。

        "好。"她听到自己说道，声音轻得几乎听不见。

        挂断电话后，她看着镜子中的自己。三年的时间，她变得更加成熟，更加独立，但是内心深处，对他的感情从未改变。

        明天，她将再次见到他。

        心情复杂如这夜色，既期待又忐忑。

        她不知道明天会发生什么，但她知道，有些人一旦出现在你的生命里，就再也无法彻底消失。

        就像现在，仅仅是一个电话，就让她的世界重新有了色彩。

        也许，这就是命运的安排。

        也许，有些爱情值得等待。

        夜深了，但她却毫无睡意。她站在窗前，看着城市的灯火，想着明天的相遇，心中五味杂陈。

        这个夜晚，注定无眠。`;
    }

    // 打开设置面板
    openSettings() {
        this.elements.settingsPanel.classList.add('active');
        this.elements.settingsOverlay.classList.remove('opacity-0', 'invisible');
        this.elements.settingsOverlay.classList.add('opacity-100', 'visible');
        document.body.style.overflow = 'hidden';
    }

    // 关闭设置面板
    closeSettings() {
        this.elements.settingsPanel.classList.remove('active');
        this.elements.settingsOverlay.classList.remove('opacity-100', 'visible');
        this.elements.settingsOverlay.classList.add('opacity-0', 'invisible');
        document.body.style.overflow = '';
    }

    // 改变字体大小
    changeFontSize(delta) {
        const newSize = Math.max(12, Math.min(24, this.settings.fontSize + delta));
        if (newSize === this.settings.fontSize) {
            const message = newSize === 12 ? '字体已经是最小了' : '字体已经是最大了';
            this.showToast(message, 'info');
            return;
        }

        this.settings.fontSize = newSize;

        this.elements.novelContent.style.fontSize = `${newSize}px`;
        this.elements.fontSizeLabel.textContent = `${newSize}px`;

        // 重新应用智能排版
        this.applySmartTypography();

        this.saveSettings();
        this.showToast(`字体大小已调整为 ${newSize}px`);
    }

    // 改变主题
    changeTheme(theme) {
        if (theme === this.settings.theme) {
            return;
        }

        this.settings.theme = theme;

        document.body.className = `theme-${theme}`;
        this.elements.themeButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === theme);
        });

        this.updateSettingsPanelTheme();
        this.saveSettings();

        const themeNames = {
            'light': '白天模式',
            'sepia': '护眼模式',
            'dark': '夜间模式',
            'paper': '纸质感',
            'green': '护眼绿',
            'blue': '海洋蓝',
            'custom': '自定义主题'
        };
        this.showToast(`已切换到${themeNames[theme]}`);

        // 如果切换到自定义主题，应用自定义颜色
        if (theme === 'custom') {
            this.applyCustomThemeStyles();
        }
    }

    // 打开自定义主题面板
    openCustomThemePanel() {
        this.closeSettings(); // 先关闭设置面板
        this.elements.customThemePanel.classList.add('active');
        this.elements.settingsOverlay.classList.remove('opacity-0', 'invisible');
        this.elements.settingsOverlay.classList.add('opacity-100', 'visible');
        document.body.style.overflow = 'hidden';

        // 初始化颜色选择器的值
        this.initializeCustomThemeControls();
    }

    // 关闭自定义主题面板
    closeCustomThemePanel() {
        this.elements.customThemePanel.classList.remove('active');
        this.elements.settingsOverlay.classList.remove('opacity-100', 'visible');
        this.elements.settingsOverlay.classList.add('opacity-0', 'invisible');
        document.body.style.overflow = '';
    }

    // 初始化自定义主题控件
    initializeCustomThemeControls() {
        const custom = this.settings.customTheme;

        this.elements.bgColorPicker.value = custom.backgroundColor;
        this.elements.bgColorInput.value = custom.backgroundColor;
        this.elements.textColorPicker.value = custom.textColor;
        this.elements.textColorInput.value = custom.textColor;
        this.elements.contentBgColorPicker.value = custom.contentBackgroundColor;
        this.elements.contentBgColorInput.value = custom.contentBackgroundColor;
    }

    // 应用预设颜色方案
    applyPresetColors(preset) {
        const presets = {
            warm: {
                backgroundColor: '#FFF8DC',
                textColor: '#8B4513',
                contentBackgroundColor: '#FFFEF7'
            },
            cool: {
                backgroundColor: '#F0F8FF',
                textColor: '#4682B4',
                contentBackgroundColor: '#FAFCFF'
            },
            vintage: {
                backgroundColor: '#F5F5DC',
                textColor: '#696969',
                contentBackgroundColor: '#FEFEFE'
            },
            forest: {
                backgroundColor: '#F0FFF0',
                textColor: '#228B22',
                contentBackgroundColor: '#FAFFFA'
            },
            sunset: {
                backgroundColor: '#FFE4E1',
                textColor: '#CD5C5C',
                contentBackgroundColor: '#FFF5F5'
            },
            ocean: {
                backgroundColor: '#E0FFFF',
                textColor: '#008B8B',
                contentBackgroundColor: '#F0FFFF'
            }
        };

        const colors = presets[preset];
        if (colors) {
            this.elements.bgColorPicker.value = colors.backgroundColor;
            this.elements.bgColorInput.value = colors.backgroundColor;
            this.elements.textColorPicker.value = colors.textColor;
            this.elements.textColorInput.value = colors.textColor;
            this.elements.contentBgColorPicker.value = colors.contentBackgroundColor;
            this.elements.contentBgColorInput.value = colors.contentBackgroundColor;
        }
    }

    // 应用自定义主题颜色
    applyCustomThemeColors() {
        // 保存自定义颜色到设置
        this.settings.customTheme = {
            backgroundColor: this.elements.bgColorInput.value,
            textColor: this.elements.textColorInput.value,
            contentBackgroundColor: this.elements.contentBgColorInput.value
        };

        // 切换到自定义主题
        this.settings.theme = 'custom';
        document.body.className = 'theme-custom';

        // 更新主题按钮状态
        this.elements.themeButtons.forEach(btn => {
            btn.classList.remove('active');
        });

        // 应用自定义样式
        this.applyCustomThemeStyles();

        // 保存设置
        this.saveSettings();

        // 关闭面板并显示提示
        this.closeCustomThemePanel();
        this.showToast('自定义主题已应用');
    }

    // 应用自定义主题样式
    applyCustomThemeStyles() {
        const custom = this.settings.customTheme;
        const root = document.documentElement;

        // 设置CSS变量
        root.style.setProperty('--custom-bg-color', custom.backgroundColor);
        root.style.setProperty('--custom-text-color', custom.textColor);
        root.style.setProperty('--custom-content-bg-color', custom.contentBackgroundColor);

        // 应用到页面元素
        document.body.style.backgroundColor = custom.backgroundColor;
        document.body.style.color = custom.textColor;

        // 应用到内容区域
        const novelInfo = this.elements.novelInfo;
        const novelContent = this.elements.novelContent;

        if (novelInfo) {
            novelInfo.style.backgroundColor = custom.contentBackgroundColor;
            novelInfo.style.color = custom.textColor;
        }

        if (novelContent) {
            novelContent.style.backgroundColor = custom.contentBackgroundColor;
            novelContent.style.color = custom.textColor;
        }

        // 应用到设置面板
        const settingsPanel = this.elements.settingsPanel;
        if (settingsPanel) {
            settingsPanel.style.backgroundColor = custom.contentBackgroundColor;
            settingsPanel.style.color = custom.textColor;
        }

        // 应用到头部
        const header = document.querySelector('header');
        if (header) {
            header.style.backgroundColor = custom.backgroundColor + 'E6'; // 90% opacity
            header.style.color = custom.textColor;
        }
    }

    // 重置自定义主题颜色
    resetCustomThemeColors() {
        this.elements.bgColorPicker.value = '#FAF5F0';
        this.elements.bgColorInput.value = '#FAF5F0';
        this.elements.textColorPicker.value = '#333333';
        this.elements.textColorInput.value = '#333333';
        this.elements.contentBgColorPicker.value = '#FFFFFF';
        this.elements.contentBgColorInput.value = '#FFFFFF';

        this.showToast('已重置为默认颜色');
    }

    // 更新进度条
    updateProgressBar() {
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = window.scrollY;
        const percentage = scrollHeight > 0 ? (scrolled / scrollHeight) * 100 : 0;
        
        this.elements.progressBar.style.width = `${percentage}%`;
    }

    // 保存阅读进度
    saveProgress() {
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = window.scrollY;
        const percentage = scrollHeight > 0 ? (scrolled / scrollHeight) * 100 : 0;
        
        const progress = {
            position: scrolled,
            percentage: percentage,
            timestamp: Date.now()
        };
        
        localStorage.setItem(`novel-${this.novelId}-progress`, JSON.stringify(progress));
    }

    // 恢复阅读进度
    restoreProgress() {
        if (this.readingProgress.position > 0) {
            window.scrollTo({
                top: this.readingProgress.position,
                behavior: 'smooth'
            });
        }
    }

    // 保存设置
    saveSettings() {
        localStorage.setItem('readerSettings', JSON.stringify(this.settings));
    }

    // 格式化内容
    formatContent(content) {
        if (!content) return '<p class="text-center text-gray-500 py-8">暂无内容</p>';
        
        const paragraphs = content.split('\n').filter(p => p.trim());
        
        return paragraphs.map(paragraph => {
            paragraph = paragraph.trim();
            
            // 检查是否是章节标题
            if (paragraph.match(/^第.+章/)) {
                return `<h2 class="text-xl font-bold mt-8 mb-4 text-center">${paragraph}</h2>`;
            }
            
            // 检查是否是其他标题格式
            if (paragraph.match(/^【.+】$/) || paragraph.match(/^\d+\./)) {
                return `<h3 class="text-lg font-semibold mt-6 mb-3">${paragraph}</h3>`;
            }
            
            // 普通段落
            return `<p>${paragraph}</p>`;
        }).join('');
    }

    // 格式化阅读量
    formatViews(views) {
        if (views >= 10000) {
            return Math.floor(views / 1000) / 10 + 'w';
        } else if (views >= 1000) {
            return Math.floor(views / 100) / 10 + 'k';
        }
        return views.toString();
    }

    // 格式化发布时间
    formatPublishTime(publishTime) {
        if (!publishTime) return '未知时间';
        
        const date = new Date(publishTime);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) return '1天前';
        if (diffDays < 7) return `${diffDays}天前`;
        if (diffDays < 30) return `${Math.floor(diffDays / 7)}周前`;
        if (diffDays < 365) return `${Math.floor(diffDays / 30)}个月前`;
        return `${Math.floor(diffDays / 365)}年前`;
    }

    // 增加阅读量（模拟功能）
    incrementViews(novelId) {
        const viewKey = `novel-${novelId}-viewed`;
        const lastViewed = localStorage.getItem(viewKey);
        const now = Date.now();
        
        // 如果距离上次查看超过1小时，则增加阅读量
        if (!lastViewed || (now - parseInt(lastViewed)) > 3600000) {
            localStorage.setItem(viewKey, now.toString());
            // 这里可以发送请求到服务器增加阅读量
            console.log(`增加小说${novelId}的阅读量`);
        }
    }

    // 显示错误信息
    showError(message) {
        this.elements.novelContent.innerHTML = `
            <div class="text-center py-20">
                <div class="text-6xl mb-4">😔</div>
                <h2 class="text-xl font-semibold text-gray-700 mb-2">出错了</h2>
                <p class="text-gray-500 mb-6">${message}</p>
                <div class="space-x-4">
                    <button onclick="location.reload()"
                            class="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                        重新加载
                    </button>
                    <button onclick="window.history.back()"
                            class="px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                        返回上一页
                    </button>
                </div>
            </div>
        `;
    }

    // 显示成功提示
    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            'bg-blue-500 text-white'
        }`;
        toast.textContent = message;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('translate-x-full');
        }, 100);

        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, 3000);
    }

    // 初始化离线管理器
    async initOfflineManager() {
        if (typeof OfflineReaderManager !== 'undefined') {
            this.offlineManager = new OfflineReaderManager();

            // 检查当前小说是否已离线保存
            if (this.novelId) {
                try {
                    const isOfflineAvailable = await this.offlineManager.isNovelAvailableOffline(this.novelId);
                    this.updateOfflineIndicator(isOfflineAvailable);
                } catch (error) {
                    console.error('检查离线状态失败:', error);
                }
            }
        }
    }

    // 更新离线状态指示器
    updateOfflineIndicator(isOffline) {
        const indicator = document.getElementById('offlineIndicator');
        if (indicator) {
            if (isOffline) {
                indicator.classList.remove('hidden');
            } else {
                indicator.classList.add('hidden');
            }
        }
    }

    updateOfflineStatus(isOffline, isOfflineNeeded = false) {
        // 更新状态指示器
        if (this.elements.offlineStatus) {
            if (isOffline) {
                this.elements.offlineStatus.innerHTML = `
                    <span class="offline-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
                        </svg>
                        离线阅读中
                    </span>
                `;
                this.elements.offlineStatus.classList.remove('hidden');
            } else if (isOfflineNeeded) {
                this.elements.offlineStatus.innerHTML = `
                    <span class="offline-needed-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        需要离线保存
                    </span>
                `;
                this.elements.offlineStatus.classList.remove('hidden');
            } else {
                this.elements.offlineStatus.classList.add('hidden');
            }
        }
        
        // 更新离线下载按钮状态
        if (this.elements.offlineDownloadBtn) {
            if (isOffline) {
                this.elements.offlineDownloadBtn.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5.002 5.002 0 0010 2z" />
                    </svg>
                    已保存离线
                `;
                this.elements.offlineDownloadBtn.classList.add('saved');
            } else {
                this.elements.offlineDownloadBtn.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    保存离线阅读
                `;
                this.elements.offlineDownloadBtn.classList.remove('saved');
            }
        }
    }
    
    // 下载小说供离线阅读
    async downloadForOfflineReading() {
        if (!this.novelId) {
            this.showToast('无效的小说ID', 'error');
            return;
        }
        
        try {
            this.showToast('正在保存小说到离线库...', 'info');
            
            const result = await this.offlineManager.downloadNovel(this.novelId);
            
            if (result.success) {
                this.showToast(result.message, 'success');
                this.updateOfflineStatus(true);
            } else {
                this.showToast(result.message, 'warning');
            }
        } catch (error) {
            console.error('保存离线阅读失败:', error);
            this.showToast('保存失败: ' + (error.message || '未知错误'), 'error');
        }
    }
}

// 页面加载完成后初始化阅读器
document.addEventListener('DOMContentLoaded', () => {
    new NovelReader();
});