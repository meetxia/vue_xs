// 离线阅读功能实现
class OfflineReaderManager {
    constructor() {
        this.dbName = 'novel_offline_db';
        this.dbVersion = 1;
        this.db = null;
        this.maxStorageSize = 50 * 1024 * 1024; // 默认50MB存储限制
        this.storageLimit = parseInt(localStorage.getItem('offline_storage_limit')) || this.maxStorageSize;
        this.downloadQueue = [];
        this.isProcessingQueue = false;
        
        this.initDatabase();
        this.initNetworkListeners();
    }

    // 初始化IndexedDB数据库
    async initDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // 创建小说内容存储
                if (!db.objectStoreNames.contains('novels')) {
                    const novelStore = db.createObjectStore('novels', { keyPath: 'id' });
                    novelStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
                
                // 创建小说章节存储
                if (!db.objectStoreNames.contains('chapters')) {
                    const chapterStore = db.createObjectStore('chapters', { keyPath: 'id' });
                    chapterStore.createIndex('novelId', 'novelId', { unique: false });
                    chapterStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
                
                // 创建下载任务存储
                if (!db.objectStoreNames.contains('downloadTasks')) {
                    const taskStore = db.createObjectStore('downloadTasks', { keyPath: 'id', autoIncrement: true });
                    taskStore.createIndex('status', 'status', { unique: false });
                    taskStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
            };
            
            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log('离线阅读数据库初始化成功');
                resolve(this.db);
            };
            
            request.onerror = (event) => {
                console.error('离线阅读数据库初始化失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 初始化网络状态监听
    initNetworkListeners() {
        window.addEventListener('online', () => {
            console.log('网络已连接，可以同步数据');
            this.processDownloadQueue();
            
            // 显示网络已连接通知
            if (this.showToast) {
                this.showToast('网络已连接，正在同步数据', 'success');
            }
        });
        
        window.addEventListener('offline', () => {
            console.log('网络已断开，切换到离线模式');
            
            // 显示网络已断开通知
            if (this.showToast) {
                this.showToast('网络已断开，已切换到离线模式', 'info');
            }
        });
    }
    
    // 检查是否在线
    isOnline() {
        return navigator.onLine;
    }
    
    // 保存小说到离线存储
    async saveNovel(novel) {
        if (!this.db) await this.initDatabase();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['novels'], 'readwrite');
            const store = transaction.objectStore('novels');
            
            // 添加时间戳用于过期处理
            novel.timestamp = Date.now();
            novel.size = this.estimateSize(novel);
            
            const request = store.put(novel);
            
            request.onsuccess = () => {
                resolve(novel);
            };
            
            request.onerror = (event) => {
                console.error('保存小说失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 获取离线小说
    async getNovel(novelId) {
        if (!this.db) await this.initDatabase();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['novels'], 'readonly');
            const store = transaction.objectStore('novels');
            const request = store.get(parseInt(novelId));
            
            request.onsuccess = (event) => {
                const novel = event.target.result;
                if (novel) {
                    // 更新最后访问时间
                    this.updateNovelTimestamp(parseInt(novelId));
                }
                resolve(novel);
            };
            
            request.onerror = (event) => {
                console.error('获取小说失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 更新小说的时间戳（最后访问时间）
    async updateNovelTimestamp(novelId) {
        if (!this.db) await this.initDatabase();
        
        const transaction = this.db.transaction(['novels'], 'readwrite');
        const store = transaction.objectStore('novels');
        
        const request = store.get(parseInt(novelId));
        request.onsuccess = (event) => {
            const novel = event.target.result;
            if (novel) {
                novel.timestamp = Date.now();
                store.put(novel);
            }
        };
    }
    
    // 删除离线小说
    async deleteNovel(novelId) {
        if (!this.db) await this.initDatabase();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['novels'], 'readwrite');
            const store = transaction.objectStore('novels');
            const request = store.delete(parseInt(novelId));
            
            request.onsuccess = () => {
                resolve(true);
            };
            
            request.onerror = (event) => {
                console.error('删除小说失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 获取所有离线小说列表
    async getAllNovels() {
        if (!this.db) await this.initDatabase();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['novels'], 'readonly');
            const store = transaction.objectStore('novels');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                const novels = event.target.result;
                resolve(novels || []);
            };
            
            request.onerror = (event) => {
                console.error('获取离线小说列表失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 下载小说到离线存储
    async downloadNovel(novelId) {
        // 先检查是否已经离线保存
        const existingNovel = await this.getNovel(novelId);
        if (existingNovel) {
            return { success: true, message: '小说已离线保存', novel: existingNovel };
        }
        
        // 检查网络状态
        if (!this.isOnline()) {
            this.addToDownloadQueue(novelId);
            return { success: false, message: '网络已断开，已添加到下载队列' };
        }
        
        try {
            console.log(`正在从API获取小说数据: /api/novels/${novelId}`);

            const response = await fetch(`/api/novels/${novelId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            console.log(`API响应状态: ${response.status}`);

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`API错误响应: ${response.status} - ${errorText}`);
                throw new Error(`API返回错误: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            console.log('API返回数据:', data);

            if (!data.success || !data.data) {
                throw new Error(`获取小说数据失败: ${data.message || '未知错误'}`);
            }
            
            // 检查存储空间
            await this.checkAndCleanStorage(data.data);
            
            // 保存到离线存储
            const savedNovel = await this.saveNovel(data.data);
            
            // 通知保存成功
            if (this.showToast) {
                this.showToast(`《${savedNovel.title}》已保存到离线阅读库`, 'success');
            }
            
            return { success: true, message: '小说已保存到离线阅读库', novel: savedNovel };
        } catch (error) {
            console.error('下载小说失败:', error);
            
            // 添加到下载队列，稍后重试
            this.addToDownloadQueue(novelId);
            
            return { success: false, message: `下载失败: ${error.message}，已加入下载队列`, error };
        }
    }
    
    // 添加到下载队列
    addToDownloadQueue(novelId) {
        const task = {
            novelId: parseInt(novelId),
            status: 'pending',
            timestamp: Date.now(),
            retries: 0
        };
        
        if (!this.db) {
            this.downloadQueue.push(task);
            return;
        }
        
        const transaction = this.db.transaction(['downloadTasks'], 'readwrite');
        const store = transaction.objectStore('downloadTasks');
        store.add(task);
        
        // 如果在线且队列未处理，开始处理
        if (this.isOnline() && !this.isProcessingQueue) {
            this.processDownloadQueue();
        }
    }
    
    // 处理下载队列
    async processDownloadQueue() {
        if (!this.isOnline() || this.isProcessingQueue) return;
        
        this.isProcessingQueue = true;
        
        if (!this.db) await this.initDatabase();
        
        const transaction = this.db.transaction(['downloadTasks'], 'readwrite');
        const store = transaction.objectStore('downloadTasks');
        const index = store.index('status');
        const request = index.getAll('pending');
        
        request.onsuccess = async (event) => {
            const tasks = event.target.result;
            
            for (const task of tasks) {
                if (!this.isOnline()) {
                    this.isProcessingQueue = false;
                    return;
                }
                
                try {
                    const result = await this.downloadNovel(task.novelId);
                    
                    // 更新任务状态
                    const updateTransaction = this.db.transaction(['downloadTasks'], 'readwrite');
                    const updateStore = updateTransaction.objectStore('downloadTasks');
                    
                    if (result.success) {
                        // 成功，删除任务
                        updateStore.delete(task.id);
                    } else {
                        // 失败，增加重试次数
                        task.retries++;
                        task.lastError = result.message;
                        
                        if (task.retries >= 3) {
                            task.status = 'failed';
                        }
                        
                        updateStore.put(task);
                    }
                } catch (error) {
                    console.error('处理下载队列任务失败:', error);
                }
            }
            
            this.isProcessingQueue = false;
        };
        
        request.onerror = (event) => {
            console.error('获取下载队列失败:', event.target.error);
            this.isProcessingQueue = false;
        };
    }
    
    // 获取缓存使用情况
    async getStorageUsage() {
        if (!this.db) await this.initDatabase();
        
        const novels = await this.getAllNovels();
        
        let totalSize = 0;
        let novelCount = novels.length;
        
        for (const novel of novels) {
            totalSize += novel.size || 0;
        }
        
        return {
            totalSize,
            sizeLimit: this.storageLimit,
            usedPercentage: Math.round((totalSize / this.storageLimit) * 100),
            novelCount
        };
    }
    
    // 估算内容大小
    estimateSize(novel) {
        let size = 0;
        
        // 标题和作者
        size += (novel.title?.length || 0) * 2;
        size += (novel.author?.length || 0) * 2;
        
        // 内容
        size += (novel.content?.length || 0) * 2;
        
        // 摘要和标签
        size += (novel.summary?.length || 0) * 2;
        size += JSON.stringify(novel.tags || []).length;
        
        // 其他元数据
        size += JSON.stringify(novel).length;
        
        return size;
    }
    
    // 检查存储空间并清理过期数据
    async checkAndCleanStorage(newNovel = null) {
        const usage = await this.getStorageUsage();
        const newSize = newNovel ? this.estimateSize(newNovel) : 0;
        
        // 如果添加新内容后超过限制，清理旧数据
        if (usage.totalSize + newSize > this.storageLimit) {
            const novels = await this.getAllNovels();
            
            // 按最后访问时间排序
            novels.sort((a, b) => a.timestamp - b.timestamp);
            
            let freedSpace = 0;
            const needToFree = usage.totalSize + newSize - this.storageLimit + 1024 * 1024; // 额外释放1MB空间
            
            for (const novel of novels) {
                await this.deleteNovel(novel.id);
                freedSpace += novel.size || 0;
                
                if (freedSpace > needToFree) break;
            }
        }
    }
    
    // 清除全部离线数据
    async clearAllOfflineData() {
        if (!this.db) await this.initDatabase();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['novels', 'downloadTasks'], 'readwrite');
            
            // 清除小说
            const novelStore = transaction.objectStore('novels');
            const novelClear = novelStore.clear();
            
            // 清除下载任务
            const taskStore = transaction.objectStore('downloadTasks');
            const taskClear = taskStore.clear();
            
            transaction.oncomplete = () => {
                resolve(true);
            };
            
            transaction.onerror = (event) => {
                console.error('清除离线数据失败:', event.target.error);
                reject(event.target.error);
            };
        });
    }
    
    // 设置存储限制
    setStorageLimit(limitInMB) {
        const limit = Math.max(10, Math.min(500, limitInMB)) * 1024 * 1024; // 限制在10-500MB之间
        this.storageLimit = limit;
        localStorage.setItem('offline_storage_limit', limit.toString());
    }
    
    // 检查小说是否离线可用
    async isNovelAvailableOffline(novelId) {
        const novel = await this.getNovel(novelId);
        return !!novel;
    }
    
    // 注册Toast通知函数
    registerToastFunction(toastFn) {
        this.showToast = toastFn;
    }
}

// 导出为全局变量
window.OfflineReaderManager = OfflineReaderManager; 